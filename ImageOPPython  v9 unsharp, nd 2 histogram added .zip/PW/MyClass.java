public class MyClass {
    public static void main(String args[]) {
        A a = new A();
        a = 4;
        a.print();
    }
}
class A{
    int x;
    A(int temp){
        x = temp;
    }
    void print(){
        System.out.print(x);
    }
}
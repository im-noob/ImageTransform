
import cv2
import numpy as np
import math
from Implementation import Utility as ut
from Implementation import Input
from Implementation import Transform

def main():
    """the code for GUI goes here
    rewrite the whole thing, i just put some sample code ^_^ """

    transform = Transform.Transform()
    input = Input.Input()
    input.image = ut.load("HD.jpg")
    input.method = "scale"
    input.interpolation = "lanczos4" #lanczos4
    input.fx = 1 
    input.fy = 0.5
    r = 90

    input.x = 100
    input.y = 100
    input.z = 300
    input.a11 = math.cos(math.radians(r))
    input.a12 = -math.sin(math.radians(r))
    input.a21 = math.sin(math.radians(r))
    input.a22 = math.cos(math.radians(r))

    input.r = math.radians(0)

    result = transform.trans(input)
    ut.display_image(result)







if __name__ == "__main__":
    main()
#streched historgram

# import cv2
# import numpy as np
# from matplotlib import pyplot as plt

# img = cv2.imread('hot.jpg',0)

# hist,bins = np.histogram(img.flatten(),256,[0,256])

# cdf = hist.cumsum()
# cdf_normalized = cdf * hist.max()/ cdf.max()

# plt.plot(cdf_normalized, color = 'b')
# plt.hist(img.flatten(),256,[0,256], color = 'r')
# plt.xlim([0,256])
# plt.legend(('cdf','histogram'), loc = 'upper left')
# plt.show()




# #plot histogram
# import cv2
# import numpy as np
# from matplotlib import pyplot as plt

# img = cv2.imread('hot.jpg')
# color = ('b','g','r')
# for i,col in enumerate(color):
#     histr = cv2.calcHist([img],[i],None,[256],[0,256])
#     plt.plot(histr,color = col)
#     plt.xlim([0,256])
# plt.show()




import cv2
import matplotlib.pyplot as plt
from scipy.ndimage.filters import median_filter
import numpy as np
import cv2
import PIL.Image, PIL.ImageTk
original_image = plt.imread('per.jpeg').astype('uint16')

# Convert to grayscale
gray_image = cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY)

# Median filtering
gray_image_mf = median_filter(gray_image, 1)

# Calculate the Laplacian
lap = cv2.Laplacian(gray_image_mf,cv2.CV_64F)

# Calculate the sharpened image
sharp = gray_image - 0.9*lap
# img = PIL.ImageTk.PhotoImage(image = PIL.Image.fromarray(sharp))
# plt.show()
cv2.imshow('image',sharp)
while True:
	k = cv2.waitKey(100) 
	# change the value from the original 0 (wait forever) to something appropriate
	if k == 27:
		print('ESC')
		cv2.destroyAllWindows()
		break        
	if cv2.getWindowProperty('image',cv2.WND_PROP_VISIBLE) < 1:        
		break        
# cv2.destroyAllWindows()


# cv2.imshow("test", sharp)
# k = cv2.waitKey(0) & 0xFF





# import cv2

# image = cv2.imread("hot.jpg")
# gaussian_3 = cv2.GaussianBlur(image, (9,9), 10.0)
# unsharp_image = cv2.addWeighted(image, 1.5, gaussian_3, -0.5, 0, image)
# cv2.imwrite("lenna_unsharp.jpg", unsharp_image)+
# cv2.imshow("test", unsharp_image)
# k = cv2.waitKey(0) & 0xFF


